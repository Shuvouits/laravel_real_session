<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;

class ProfileController extends Controller
{
    public function index(Request $request)
    {
        $email = $request->input('email');
        $password = $request->input('password');
        $c_password = $request->input('c_password');

        if($password == $c_password)
        {
            session()->put('email',$email);
            $session_email = session()->get('email');
            //print_r($session_email);
            return view('profile',compact('email'));
        }else{
            return redirect('/');
        }
    }

    public function logout()
    {
        Session::flush();
        return redirect('/');
    }
}

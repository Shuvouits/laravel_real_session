<!DOCTYPE html>
<html>
<head>
	<title>Sign Up Page</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container">
		<div class="row jumbotron">
			<div class="col-md-6 col-md-offset-3">
			     <h4 class="text-center" style="font-weight: bold">Sign-Up</h4>
			     <form action="signUp" method="post">
			     	<?php echo e(@csrf_field()); ?>

			     	<div class="form-group">
			     		<label>E-Mail</label>
			     		<input type="email" name="email" class="form-control" required>
			     	</div>
			     	<div class="form-group">
			     		<label>Password</label>
			     		<input type="Password" name="password" class="form-control" required>
			     	</div>
			     	<div class="form-group">
			     		<label>Confirm-Password</label>
			     		<input type="password" name="c_password" class="form-control" required>
			     	</div>
			     	<div class="col-md-12 text-center">
			     	      <input type="submit" name="submit" value="Submit" class="btn btn-primary">
			         </div>
			     </form>
			 </div>
		</div>
	</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel_middleware\laravel\resources\views/signUp.blade.php ENDPATH**/ ?>